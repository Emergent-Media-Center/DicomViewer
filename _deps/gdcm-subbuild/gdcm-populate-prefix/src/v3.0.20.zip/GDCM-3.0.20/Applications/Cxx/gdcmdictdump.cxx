/*
* TODO: Is this really useful ?
* Dump the dict from a DICOM file. Useful for the private dict
*/
