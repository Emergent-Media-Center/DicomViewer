php -d enable_dl=On test.php
sudo cp bin/gdcm.so /usr/lib/php5/20090626/gdcm.so
